CREATE DEFINER=`root`@`localhost` FUNCTION `get_fiscal_quarter`(
	calendar_year DATE
) RETURNS varchar(10) CHARSET utf8mb4
    DETERMINISTIC
BEGIN
	DECLARE fiscal_quarter varchar(10);
    SET fiscal_quarter = CASE 
		WHEN MONTH(calendar_year) IN (09,10,11) THEN "Q1"
        WHEN MONTH(calendar_year) IN (12,01,02) THEN "Q2"
        WHEN MONTH(calendar_year) IN (03,04,05) THEN "Q3"
        WHEN MONTH(calendar_year) IN (06,07,08) THEN "Q4"
    END;
RETURN fiscal_quarter;
END