CREATE DEFINER=`root`@`localhost` PROCEDURE `get_top_n_markets_by_net_sales`(
	in_fiscal_year INT,
    in_top_n INT
)
BEGIN
	SELECT market, round(sum(net_sales)/1000000,2) as net_sales_mln 
	FROM gdb0041.net_sales
	WHERE fiscal_year=in_fiscal_year
	GROUP BY market
	ORDER BY net_sales_mln DESC
	LIMIT in_top_n ;
END