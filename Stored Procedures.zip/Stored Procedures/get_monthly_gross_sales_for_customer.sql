CREATE DEFINER=`root`@`localhost` PROCEDURE `get_monthly_gross_sales_for_customer`(
	customer_list TEXT
)
BEGIN
	SELECT s.date, SUM(s.sold_quantity * g.gross_price) as total_gross_price
	FROM fact_sales_monthly s
	JOIN fact_gross_price g
	on s.product_code=g.product_code and g.fiscal_year = get_fiscal_year(s.date)
	WHERE find_in_set(s.customer_code,customer_list)>0
	Group by s.date;
END