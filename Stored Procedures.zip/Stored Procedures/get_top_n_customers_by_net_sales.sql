CREATE DEFINER=`root`@`localhost` PROCEDURE `get_top_n_customers_by_net_sales`(
	in_fiscal_year INT,
    in_top_n INT
)
BEGIN
SELECT c.customer, round(sum(net_sales)/1000000,2) as net_sales_mln 
FROM gdb0041.net_sales n
JOIN dim_customer c
ON c.customer_code=n.customer_code
WHERE fiscal_year=in_fiscal_year
GROUP BY c.customer
ORDER BY net_sales_mln DESC
LIMIT in_top_n ;
END